namespace ASOSD.Web.Entities;

/// <summary>
/// Represents a navigation menu that can be placed in template regions.
/// </summary>
public class NavigationMenu
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    
    /// <summary>
    /// Display name for admin (e.g., "Main Navigation", "Footer Links").
    /// </summary>
    public string Name { get; set; } = string.Empty;
    
    /// <summary>
    /// URL-friendly identifier (e.g., "main-nav", "footer-nav").
    /// </summary>
    public string Slug { get; set; } = string.Empty;
    
    /// <summary>
    /// Optional description for admin reference.
    /// </summary>
    public string? Description { get; set; }
    
    public bool IsActive { get; set; } = true;
    
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedOn { get; set; }
    public string? UpdatedBy { get; set; }
    
    // Navigation properties
    public ICollection<NavigationItem> Items { get; set; } = new List<NavigationItem>();
    public ICollection<ContentBlock> ContentBlocks { get; set; } = new List<ContentBlock>();
}
