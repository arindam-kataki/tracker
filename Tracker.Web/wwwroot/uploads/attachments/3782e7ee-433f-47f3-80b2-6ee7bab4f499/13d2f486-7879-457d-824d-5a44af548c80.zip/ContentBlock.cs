namespace ASOSD.Web.Entities;

/// <summary>
/// Types of content blocks.
/// </summary>
public enum ContentBlockType
{
    /// <summary>
    /// Standard markdown content.
    /// </summary>
    Markdown = 0,
    
    /// <summary>
    /// Navigation menu reference.
    /// </summary>
    Navigation = 1,
    
    /// <summary>
    /// Raw HTML content.
    /// </summary>
    Html = 2
}

/// <summary>
/// Represents a reusable content block that can be assigned to template regions.
/// Content blocks are identified by a unique key for easy reference.
/// Supports multiple content types: Markdown, Navigation, or Html.
/// </summary>
public class ContentBlock
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string Key { get; set; } = string.Empty; // Unique key, e.g., "venue-info", "sponsor-logos", "main-nav"
    public string Title { get; set; } = string.Empty;
    public string? Description { get; set; } // Admin description of what this block is for
    
    /// <summary>
    /// The type of content this block contains.
    /// </summary>
    public ContentBlockType Type { get; set; } = ContentBlockType.Markdown;
    
    // Markdown content (for Type = Markdown)
    public string DraftMarkdown { get; set; } = string.Empty;
    public string? PublishedMarkdown { get; set; }
    public string? PublishedHtml { get; set; }
    
    // HTML content (for Type = Html)
    public string? HtmlContent { get; set; }
    
    // Navigation reference (for Type = Navigation)
    public string? NavigationMenuId { get; set; }
    public NavigationMenu? NavigationMenu { get; set; }
    
    // Publishing workflow
    public bool IsPublished { get; set; } = false;
    public bool HasUnpublishedChanges => Type == ContentBlockType.Markdown 
        ? DraftMarkdown != PublishedMarkdown 
        : false;
    
    // Metadata
    public bool IsActive { get; set; } = true;
    public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
    public string? CreatedBy { get; set; }
    public DateTime? ModifiedOn { get; set; }
    public string? ModifiedBy { get; set; }
    public DateTime? PublishedOn { get; set; }
    public string? PublishedBy { get; set; }

    // Navigation - regions that use this block as default
    public ICollection<TemplateRegion> DefaultForRegions { get; set; } = new List<TemplateRegion>();
    public ICollection<PageRegionOverride> PageOverrides { get; set; } = new List<PageRegionOverride>();
}

/// <summary>
/// Allows a page to override a specific template region with different content.
/// </summary>
public class PageRegionOverride
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string PageContentId { get; set; } = string.Empty;
    public string TemplateRegionId { get; set; } = string.Empty;
    public string? ContentBlockId { get; set; } // The content block to use instead of the template default
    public string? InlineMarkdown { get; set; } // Or inline markdown content (if not using a content block)
    public string? InlineHtml { get; set; } // Rendered HTML of inline content

    // Navigation
    public PageContent? PageContent { get; set; }
    public TemplateRegion? TemplateRegion { get; set; }
    public ContentBlock? ContentBlock { get; set; }
}
