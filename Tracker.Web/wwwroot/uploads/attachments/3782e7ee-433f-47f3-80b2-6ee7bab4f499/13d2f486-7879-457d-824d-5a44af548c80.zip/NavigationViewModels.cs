using ASOSD.Web.Entities;

namespace ASOSD.Web.ViewModels;

#region Menu ViewModels

/// <summary>
/// View model for displaying a navigation menu in lists.
/// </summary>
public class NavigationMenuListViewModel
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string Slug { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; }
    public int ItemCount { get; set; }
    public DateTime CreatedOn { get; set; }
    public DateTime? UpdatedOn { get; set; }
}

/// <summary>
/// View model for editing a navigation menu with all its items.
/// </summary>
public class NavigationMenuEditViewModel
{
    public string? Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Slug { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsActive { get; set; } = true;
    public List<NavigationItemViewModel> Items { get; set; } = new();
    
    // For dropdowns
    public List<PageSelectItem> AvailablePages { get; set; } = new();
}

/// <summary>
/// Form model for creating/updating a navigation menu.
/// </summary>
public record NavigationMenuFormViewModel
{
    public string? Id { get; init; }
    public string Name { get; init; } = string.Empty;
    public string Slug { get; init; } = string.Empty;
    public string? Description { get; init; }
    public bool IsActive { get; init; } = true;
}

/// <summary>
/// Dropdown item for selecting a menu.
/// </summary>
public class NavigationMenuSelectItem
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
}

#endregion

#region Item ViewModels

/// <summary>
/// View model for displaying a navigation item.
/// </summary>
public class NavigationItemViewModel
{
    public string Id { get; set; } = string.Empty;
    public string MenuId { get; set; } = string.Empty;
    public string? ParentId { get; set; }
    public string Label { get; set; } = string.Empty;
    public NavigationItemType Type { get; set; }
    public string? PageId { get; set; }
    public string? PageTitle { get; set; }
    public string? PageSlug { get; set; }
    public bool PageIsPublished { get; set; } = true;
    public string? Url { get; set; }
    public string Target { get; set; } = "_self";
    public int DisplayOrder { get; set; }
    public int Depth { get; set; }
    public bool IsActive { get; set; }
    public string? CssClass { get; set; }
    
    // Computed
    public string TypeIcon => Type switch
    {
        NavigationItemType.Page => "bi-file-text",
        NavigationItemType.Link => "bi-link-45deg",
        NavigationItemType.Header => "bi-folder",
        _ => "bi-question"
    };
    
    public string DisplayUrl => Type switch
    {
        NavigationItemType.Page => $"/{PageSlug}",
        NavigationItemType.Link => Url ?? "",
        NavigationItemType.Header => "(dropdown)",
        _ => ""
    };
    
    public bool HasWarning => Type == NavigationItemType.Page && !PageIsPublished;
    public string? WarningMessage => HasWarning ? "Page is unpublished" : null;
    
    // Children for hierarchical display
    public List<NavigationItemViewModel> Children { get; set; } = new();
}

/// <summary>
/// Form model for creating/updating a navigation item.
/// </summary>
public record NavigationItemFormViewModel
{
    public string? Id { get; init; }
    public string MenuId { get; init; } = string.Empty;
    public string? ParentId { get; init; }
    public string Label { get; init; } = string.Empty;
    public NavigationItemType Type { get; init; } = NavigationItemType.Page;
    public string? PageId { get; init; }
    public string? Url { get; init; }
    public string Target { get; init; } = "_self";
    public int DisplayOrder { get; init; }
    public int Depth { get; init; }
    public bool IsActive { get; init; } = true;
    public string? CssClass { get; init; }
}

/// <summary>
/// Model for reordering items via AJAX.
/// </summary>
public class NavigationItemReorderViewModel
{
    public string ItemId { get; set; } = string.Empty;
    public string? NewParentId { get; set; }
    public int NewDisplayOrder { get; set; }
    public int NewDepth { get; set; }
}

/// <summary>
/// Model for bulk reordering all items.
/// </summary>
public class NavigationItemsBulkReorderViewModel
{
    public string MenuId { get; set; } = string.Empty;
    public List<NavigationItemReorderViewModel> Items { get; set; } = new();
}

#endregion

#region Helper Models

/// <summary>
/// Dropdown item for selecting a page.
/// </summary>
public class PageSelectItem
{
    public string Id { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Slug { get; set; } = string.Empty;
    public bool IsPublished { get; set; }
}

#endregion

#region Render Models

/// <summary>
/// Model for rendering navigation in templates.
/// </summary>
public class NavigationRenderModel
{
    public string MenuId { get; set; } = string.Empty;
    public string MenuName { get; set; } = string.Empty;
    public string MenuSlug { get; set; } = string.Empty;
    public List<NavigationRenderItem> Items { get; set; } = new();
}

/// <summary>
/// Single item for rendering in templates.
/// </summary>
public class NavigationRenderItem
{
    public string Label { get; set; } = string.Empty;
    public string? Url { get; set; }
    public string Target { get; set; } = "_self";
    public bool IsHeader { get; set; }
    public bool IsActive { get; set; }
    public bool IsCurrentPage { get; set; }
    public string? CssClass { get; set; }
    public List<NavigationRenderItem> Children { get; set; } = new();
    
    public bool HasChildren => Children.Count > 0;
}

#endregion
