using Microsoft.EntityFrameworkCore;
using ASOSD.Web.Data;
using ASOSD.Web.Entities;
using ASOSD.Web.Models;
using ASOSD.Web.Services.Interfaces;
using ASOSD.Web.ViewModels;

namespace ASOSD.Web.Services;

/// <summary>
/// Service for managing navigation menus and items.
/// </summary>
public class NavigationService : INavigationService
{
    private readonly AppDbContext _db;
    private const int MaxDepth = 2; // 0, 1, 2 = 3 levels

    public NavigationService(AppDbContext db)
    {
        _db = db;
    }

    #region Menus

    public async Task<List<NavigationMenuListViewModel>> GetAllMenusAsync(CancellationToken ct = default)
    {
        return await _db.NavigationMenus
            .OrderBy(m => m.Name)
            .Select(m => new NavigationMenuListViewModel
            {
                Id = m.Id,
                Name = m.Name,
                Slug = m.Slug,
                Description = m.Description,
                IsActive = m.IsActive,
                ItemCount = m.Items.Count,
                CreatedOn = m.CreatedOn,
                UpdatedOn = m.UpdatedOn
            })
            .ToListAsync(ct);
    }

    public async Task<NavigationMenuEditViewModel?> GetMenuForEditingAsync(string id, CancellationToken ct = default)
    {
        var menu = await _db.NavigationMenus
            .Include(m => m.Items)
                .ThenInclude(i => i.Page)
            .FirstOrDefaultAsync(m => m.Id == id, ct);

        if (menu == null) return null;

        return MapToEditViewModel(menu);
    }

    public async Task<NavigationMenuEditViewModel?> GetMenuBySlugAsync(string slug, CancellationToken ct = default)
    {
        var menu = await _db.NavigationMenus
            .Include(m => m.Items)
                .ThenInclude(i => i.Page)
            .FirstOrDefaultAsync(m => m.Slug == slug, ct);

        if (menu == null) return null;

        return MapToEditViewModel(menu);
    }

    public async Task<Result<NavigationMenuEditViewModel>> CreateMenuAsync(NavigationMenuFormViewModel model, string userId, CancellationToken ct = default)
    {
        var errors = ValidateMenu(model);
        if (errors.Any()) return Result.Failure<NavigationMenuEditViewModel>(errors);

        // Check for duplicate slug
        var slug = GenerateSlug(model.Slug, model.Name);
        if (await _db.NavigationMenus.AnyAsync(m => m.Slug == slug, ct))
            return Result.Failure<NavigationMenuEditViewModel>("A menu with this slug already exists.");

        var menu = new NavigationMenu
        {
            Name = model.Name.Trim(),
            Slug = slug,
            Description = model.Description?.Trim(),
            IsActive = model.IsActive,
            CreatedOn = DateTime.UtcNow,
            CreatedBy = userId
        };

        _db.NavigationMenus.Add(menu);
        await _db.SaveChangesAsync(ct);

        return Result.Success(MapToEditViewModel(menu));
    }

    public async Task<Result<NavigationMenuEditViewModel>> UpdateMenuAsync(NavigationMenuFormViewModel model, string userId, CancellationToken ct = default)
    {
        if (string.IsNullOrEmpty(model.Id))
            return Result.Failure<NavigationMenuEditViewModel>("Menu ID is required.");

        var errors = ValidateMenu(model);
        if (errors.Any()) return Result.Failure<NavigationMenuEditViewModel>(errors);

        var menu = await _db.NavigationMenus
            .Include(m => m.Items)
                .ThenInclude(i => i.Page)
            .FirstOrDefaultAsync(m => m.Id == model.Id, ct);

        if (menu == null)
            return Result.Failure<NavigationMenuEditViewModel>("Menu not found.");

        // Check for duplicate slug (excluding current)
        var slug = GenerateSlug(model.Slug, model.Name);
        if (await _db.NavigationMenus.AnyAsync(m => m.Slug == slug && m.Id != model.Id, ct))
            return Result.Failure<NavigationMenuEditViewModel>("A menu with this slug already exists.");

        menu.Name = model.Name.Trim();
        menu.Slug = slug;
        menu.Description = model.Description?.Trim();
        menu.IsActive = model.IsActive;
        menu.UpdatedOn = DateTime.UtcNow;
        menu.UpdatedBy = userId;

        await _db.SaveChangesAsync(ct);

        return Result.Success(MapToEditViewModel(menu));
    }

    public async Task<r> DeleteMenuAsync(string id, CancellationToken ct = default)
    {
        var menu = await _db.NavigationMenus
            .Include(m => m.Items)
            .Include(m => m.ContentBlocks)
            .FirstOrDefaultAsync(m => m.Id == id, ct);

        if (menu == null)
            return r.Failure("Menu not found.");

        // Check if menu is used by any content blocks
        if (menu.ContentBlocks.Any())
            return r.Failure($"Cannot delete menu. It is used by {menu.ContentBlocks.Count} content block(s).");

        _db.NavigationItems.RemoveRange(menu.Items);
        _db.NavigationMenus.Remove(menu);
        await _db.SaveChangesAsync(ct);

        return r.Success();
    }

    public async Task<List<NavigationMenuSelectItem>> GetMenusForSelectAsync(CancellationToken ct = default)
    {
        return await _db.NavigationMenus
            .Where(m => m.IsActive)
            .OrderBy(m => m.Name)
            .Select(m => new NavigationMenuSelectItem
            {
                Id = m.Id,
                Name = m.Name
            })
            .ToListAsync(ct);
    }

    #endregion

    #region Items

    public async Task<NavigationItemViewModel?> GetItemByIdAsync(string id, CancellationToken ct = default)
    {
        var item = await _db.NavigationItems
            .Include(i => i.Page)
            .FirstOrDefaultAsync(i => i.Id == id, ct);

        return item == null ? null : MapToItemViewModel(item);
    }

    public async Task<Result<NavigationItemViewModel>> AddItemAsync(NavigationItemFormViewModel model, CancellationToken ct = default)
    {
        var errors = ValidateItem(model);
        if (errors.Any()) return Result.Failure<NavigationItemViewModel>(errors);

        // Verify menu exists
        if (!await _db.NavigationMenus.AnyAsync(m => m.Id == model.MenuId, ct))
            return Result.Failure<NavigationItemViewModel>("Menu not found.");

        // Validate depth
        if (model.Depth > MaxDepth)
            return Result.Failure<NavigationItemViewModel>($"Maximum nesting depth is {MaxDepth + 1} levels.");

        // Validate parent if specified
        if (!string.IsNullOrEmpty(model.ParentId))
        {
            var parent = await _db.NavigationItems.FindAsync(new object[] { model.ParentId }, ct);
            if (parent == null)
                return Result.Failure<NavigationItemViewModel>("Parent item not found.");
            if (parent.Depth >= MaxDepth)
                return Result.Failure<NavigationItemViewModel>("Cannot add children to items at maximum depth.");
        }

        // Get next display order
        var maxOrder = await _db.NavigationItems
            .Where(i => i.MenuId == model.MenuId && i.ParentId == model.ParentId)
            .MaxAsync(i => (int?)i.DisplayOrder, ct) ?? -1;

        var item = new NavigationItem
        {
            MenuId = model.MenuId,
            ParentId = model.ParentId,
            Label = model.Label.Trim(),
            Type = model.Type,
            PageId = model.Type == NavigationItemType.Page ? model.PageId : null,
            Url = model.Type == NavigationItemType.Link ? model.Url?.Trim() : null,
            Target = model.Target,
            DisplayOrder = maxOrder + 1,
            Depth = model.Depth,
            IsActive = model.IsActive,
            CssClass = model.CssClass?.Trim()
        };

        _db.NavigationItems.Add(item);
        await _db.SaveChangesAsync(ct);

        // Reload with page info
        await _db.Entry(item).Reference(i => i.Page).LoadAsync(ct);

        return Result.Success(MapToItemViewModel(item));
    }

    public async Task<Result<NavigationItemViewModel>> UpdateItemAsync(NavigationItemFormViewModel model, CancellationToken ct = default)
    {
        if (string.IsNullOrEmpty(model.Id))
            return Result.Failure<NavigationItemViewModel>("Item ID is required.");

        var errors = ValidateItem(model);
        if (errors.Any()) return Result.Failure<NavigationItemViewModel>(errors);

        var item = await _db.NavigationItems
            .Include(i => i.Page)
            .FirstOrDefaultAsync(i => i.Id == model.Id, ct);

        if (item == null)
            return Result.Failure<NavigationItemViewModel>("Item not found.");

        item.Label = model.Label.Trim();
        item.Type = model.Type;
        item.PageId = model.Type == NavigationItemType.Page ? model.PageId : null;
        item.Url = model.Type == NavigationItemType.Link ? model.Url?.Trim() : null;
        item.Target = model.Target;
        item.IsActive = model.IsActive;
        item.CssClass = model.CssClass?.Trim();

        await _db.SaveChangesAsync(ct);

        // Reload page reference
        await _db.Entry(item).Reference(i => i.Page).LoadAsync(ct);

        return Result.Success(MapToItemViewModel(item));
    }

    public async Task<r> DeleteItemAsync(string id, CancellationToken ct = default)
    {
        var item = await _db.NavigationItems
            .Include(i => i.Children)
            .FirstOrDefaultAsync(i => i.Id == id, ct);

        if (item == null)
            return r.Failure("Item not found.");

        // Delete children recursively
        await DeleteItemAndChildrenAsync(item, ct);
        
        // Reorder remaining siblings
        await ReorderSiblingsAsync(item.MenuId, item.ParentId, ct);

        return r.Success();
    }

    public async Task<r> MoveItemUpAsync(string id, CancellationToken ct = default)
    {
        var item = await _db.NavigationItems.FindAsync(new object[] { id }, ct);
        if (item == null) return r.Failure("Item not found.");

        var previousSibling = await _db.NavigationItems
            .Where(i => i.MenuId == item.MenuId && i.ParentId == item.ParentId && i.DisplayOrder < item.DisplayOrder)
            .OrderByDescending(i => i.DisplayOrder)
            .FirstOrDefaultAsync(ct);

        if (previousSibling == null)
            return r.Failure("Item is already at the top.");

        // Swap orders
        (item.DisplayOrder, previousSibling.DisplayOrder) = (previousSibling.DisplayOrder, item.DisplayOrder);
        await _db.SaveChangesAsync(ct);

        return r.Success();
    }

    public async Task<r> MoveItemDownAsync(string id, CancellationToken ct = default)
    {
        var item = await _db.NavigationItems.FindAsync(new object[] { id }, ct);
        if (item == null) return r.Failure("Item not found.");

        var nextSibling = await _db.NavigationItems
            .Where(i => i.MenuId == item.MenuId && i.ParentId == item.ParentId && i.DisplayOrder > item.DisplayOrder)
            .OrderBy(i => i.DisplayOrder)
            .FirstOrDefaultAsync(ct);

        if (nextSibling == null)
            return r.Failure("Item is already at the bottom.");

        // Swap orders
        (item.DisplayOrder, nextSibling.DisplayOrder) = (nextSibling.DisplayOrder, item.DisplayOrder);
        await _db.SaveChangesAsync(ct);

        return r.Success();
    }

    public async Task<r> IndentItemAsync(string id, CancellationToken ct = default)
    {
        var item = await _db.NavigationItems.FindAsync(new object[] { id }, ct);
        if (item == null) return r.Failure("Item not found.");

        if (item.Depth >= MaxDepth)
            return r.Failure($"Maximum nesting depth of {MaxDepth + 1} levels reached.");

        // Find previous sibling to become new parent
        var newParent = await _db.NavigationItems
            .Where(i => i.MenuId == item.MenuId && i.ParentId == item.ParentId && i.DisplayOrder < item.DisplayOrder)
            .OrderByDescending(i => i.DisplayOrder)
            .FirstOrDefaultAsync(ct);

        if (newParent == null)
            return r.Failure("Cannot indent first item. Move it down first.");

        // Get new display order (last child of new parent)
        var maxOrder = await _db.NavigationItems
            .Where(i => i.ParentId == newParent.Id)
            .MaxAsync(i => (int?)i.DisplayOrder, ct) ?? -1;

        var oldParentId = item.ParentId;
        item.ParentId = newParent.Id;
        item.Depth = newParent.Depth + 1;
        item.DisplayOrder = maxOrder + 1;

        // Update children depths recursively
        await UpdateChildrenDepthsAsync(item.Id, item.Depth, ct);

        await _db.SaveChangesAsync(ct);

        // Reorder old siblings
        await ReorderSiblingsAsync(item.MenuId, oldParentId, ct);

        return r.Success();
    }

    public async Task<r> OutdentItemAsync(string id, CancellationToken ct = default)
    {
        var item = await _db.NavigationItems
            .Include(i => i.Parent)
            .FirstOrDefaultAsync(i => i.Id == id, ct);

        if (item == null) return r.Failure("Item not found.");

        if (item.ParentId == null)
            return r.Failure("Cannot outdent top-level item.");

        var parent = item.Parent!;
        var grandparentId = parent.ParentId;

        // Place after parent in grandparent's children
        var parentOrder = parent.DisplayOrder;
        
        // Shift items after parent
        var siblingsToShift = await _db.NavigationItems
            .Where(i => i.MenuId == item.MenuId && i.ParentId == grandparentId && i.DisplayOrder > parentOrder)
            .ToListAsync(ct);

        foreach (var sibling in siblingsToShift)
            sibling.DisplayOrder++;

        item.ParentId = grandparentId;
        item.Depth = parent.Depth;
        item.DisplayOrder = parentOrder + 1;

        // Update children depths
        await UpdateChildrenDepthsAsync(item.Id, item.Depth, ct);

        await _db.SaveChangesAsync(ct);

        // Reorder old siblings (parent's children)
        await ReorderSiblingsAsync(item.MenuId, parent.Id, ct);

        return r.Success();
    }

    public async Task<r> BulkReorderItemsAsync(NavigationItemsBulkReorderViewModel model, CancellationToken ct = default)
    {
        if (!await _db.NavigationMenus.AnyAsync(m => m.Id == model.MenuId, ct))
            return r.Failure("Menu not found.");

        foreach (var itemOrder in model.Items)
        {
            var item = await _db.NavigationItems.FindAsync(new object[] { itemOrder.ItemId }, ct);
            if (item == null) continue;

            // Validate depth
            if (itemOrder.NewDepth > MaxDepth)
                return r.Failure($"Maximum nesting depth is {MaxDepth + 1} levels.");

            item.ParentId = itemOrder.NewParentId;
            item.DisplayOrder = itemOrder.NewDisplayOrder;
            item.Depth = itemOrder.NewDepth;
        }

        await _db.SaveChangesAsync(ct);
        return r.Success();
    }

    #endregion

    #region Rendering

    public async Task<NavigationRenderModel?> GetMenuForRenderingAsync(string menuId, string? currentPageSlug = null, CancellationToken ct = default)
    {
        var menu = await _db.NavigationMenus
            .Include(m => m.Items.Where(i => i.IsActive))
                .ThenInclude(i => i.Page)
            .FirstOrDefaultAsync(m => m.Id == menuId && m.IsActive, ct);

        if (menu == null) return null;

        return BuildRenderModel(menu, currentPageSlug);
    }

    public async Task<NavigationRenderModel?> GetMenuBySlugForRenderingAsync(string slug, string? currentPageSlug = null, CancellationToken ct = default)
    {
        var menu = await _db.NavigationMenus
            .Include(m => m.Items.Where(i => i.IsActive))
                .ThenInclude(i => i.Page)
            .FirstOrDefaultAsync(m => m.Slug == slug && m.IsActive, ct);

        if (menu == null) return null;

        return BuildRenderModel(menu, currentPageSlug);
    }

    #endregion

    #region Helpers

    public async Task<List<PageSelectItem>> GetPagesForSelectAsync(CancellationToken ct = default)
    {
        return await _db.PageContents
            .Where(p => p.PageType != PageType.Content)
            .OrderBy(p => p.Title)
            .Select(p => new PageSelectItem
            {
                Id = p.Id,
                Title = p.Title,
                Slug = p.Slug,
                IsPublished = p.IsPublished
            })
            .ToListAsync(ct);
    }

    private NavigationMenuEditViewModel MapToEditViewModel(NavigationMenu menu)
    {
        var items = menu.Items
            .OrderBy(i => i.Depth)
            .ThenBy(i => i.DisplayOrder)
            .Select(MapToItemViewModel)
            .ToList();

        // Build hierarchy
        var rootItems = BuildItemHierarchy(items);

        return new NavigationMenuEditViewModel
        {
            Id = menu.Id,
            Name = menu.Name,
            Slug = menu.Slug,
            Description = menu.Description,
            IsActive = menu.IsActive,
            Items = FlattenHierarchy(rootItems)
        };
    }

    private NavigationItemViewModel MapToItemViewModel(NavigationItem item)
    {
        return new NavigationItemViewModel
        {
            Id = item.Id,
            MenuId = item.MenuId,
            ParentId = item.ParentId,
            Label = item.Label,
            Type = item.Type,
            PageId = item.PageId,
            PageTitle = item.Page?.Title,
            PageSlug = item.Page?.Slug,
            PageIsPublished = item.Page?.IsPublished ?? true,
            Url = item.Url,
            Target = item.Target,
            DisplayOrder = item.DisplayOrder,
            Depth = item.Depth,
            IsActive = item.IsActive,
            CssClass = item.CssClass
        };
    }

    private List<NavigationItemViewModel> BuildItemHierarchy(List<NavigationItemViewModel> flatItems)
    {
        var lookup = flatItems.ToLookup(i => i.ParentId);
        
        void BuildChildren(NavigationItemViewModel parent)
        {
            parent.Children = lookup[parent.Id].OrderBy(i => i.DisplayOrder).ToList();
            foreach (var child in parent.Children)
                BuildChildren(child);
        }

        var roots = lookup[null].OrderBy(i => i.DisplayOrder).ToList();
        foreach (var root in roots)
            BuildChildren(root);

        return roots;
    }

    private List<NavigationItemViewModel> FlattenHierarchy(List<NavigationItemViewModel> roots)
    {
        var result = new List<NavigationItemViewModel>();
        
        void Flatten(NavigationItemViewModel item)
        {
            result.Add(item);
            foreach (var child in item.Children.OrderBy(c => c.DisplayOrder))
                Flatten(child);
        }

        foreach (var root in roots.OrderBy(r => r.DisplayOrder))
            Flatten(root);

        return result;
    }

    private NavigationRenderModel BuildRenderModel(NavigationMenu menu, string? currentPageSlug)
    {
        var items = menu.Items
            .Where(i => i.IsActive)
            .OrderBy(i => i.Depth)
            .ThenBy(i => i.DisplayOrder)
            .ToList();

        var renderItems = items.Select(i => new NavigationRenderItem
        {
            Label = i.Label,
            Url = i.Type switch
            {
                NavigationItemType.Page => i.Page != null ? $"/{i.Page.Slug}" : "#",
                NavigationItemType.Link => i.Url,
                NavigationItemType.Header => null,
                _ => null
            },
            Target = i.Target,
            IsHeader = i.Type == NavigationItemType.Header,
            IsActive = i.IsActive,
            IsCurrentPage = i.Type == NavigationItemType.Page && i.Page?.Slug == currentPageSlug,
            CssClass = i.CssClass
        }).ToList();

        // Build hierarchy for render items
        var lookup = items.ToLookup(i => i.ParentId);
        var renderLookup = items.Zip(renderItems).ToDictionary(x => x.First.Id, x => x.Second);

        foreach (var item in items.Where(i => i.ParentId != null))
        {
            if (renderLookup.TryGetValue(item.ParentId!, out var parent))
                parent.Children.Add(renderLookup[item.Id]);
        }

        return new NavigationRenderModel
        {
            MenuId = menu.Id,
            MenuName = menu.Name,
            MenuSlug = menu.Slug,
            Items = items.Where(i => i.ParentId == null)
                         .OrderBy(i => i.DisplayOrder)
                         .Select(i => renderLookup[i.Id])
                         .ToList()
        };
    }

    private List<string> ValidateMenu(NavigationMenuFormViewModel model)
    {
        var errors = new List<string>();
        
        if (string.IsNullOrWhiteSpace(model.Name))
            errors.Add("Name is required.");
        
        return errors;
    }

    private List<string> ValidateItem(NavigationItemFormViewModel model)
    {
        var errors = new List<string>();
        
        if (string.IsNullOrWhiteSpace(model.Label))
            errors.Add("Label is required.");
        
        if (model.Type == NavigationItemType.Page && string.IsNullOrEmpty(model.PageId))
            errors.Add("Please select a page.");
        
        if (model.Type == NavigationItemType.Link && string.IsNullOrWhiteSpace(model.Url))
            errors.Add("URL is required for external links.");
        
        return errors;
    }

    private string GenerateSlug(string? slug, string name)
    {
        var baseSlug = !string.IsNullOrWhiteSpace(slug) ? slug : name;
        return baseSlug.ToLower()
            .Replace(" ", "-")
            .Replace("_", "-");
    }

    private async Task DeleteItemAndChildrenAsync(NavigationItem item, CancellationToken ct)
    {
        var children = await _db.NavigationItems
            .Where(i => i.ParentId == item.Id)
            .ToListAsync(ct);

        foreach (var child in children)
            await DeleteItemAndChildrenAsync(child, ct);

        _db.NavigationItems.Remove(item);
        await _db.SaveChangesAsync(ct);
    }

    private async Task ReorderSiblingsAsync(string menuId, string? parentId, CancellationToken ct)
    {
        var siblings = await _db.NavigationItems
            .Where(i => i.MenuId == menuId && i.ParentId == parentId)
            .OrderBy(i => i.DisplayOrder)
            .ToListAsync(ct);

        for (int i = 0; i < siblings.Count; i++)
            siblings[i].DisplayOrder = i;

        await _db.SaveChangesAsync(ct);
    }

    private async Task UpdateChildrenDepthsAsync(string parentId, int parentDepth, CancellationToken ct)
    {
        var children = await _db.NavigationItems
            .Where(i => i.ParentId == parentId)
            .ToListAsync(ct);

        foreach (var child in children)
        {
            child.Depth = parentDepth + 1;
            await UpdateChildrenDepthsAsync(child.Id, child.Depth, ct);
        }
    }

    #endregion
}
