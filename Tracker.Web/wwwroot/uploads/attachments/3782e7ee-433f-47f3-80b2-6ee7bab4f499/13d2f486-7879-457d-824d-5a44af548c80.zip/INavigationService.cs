using ASOSD.Web.Models;
using ASOSD.Web.ViewModels;

namespace ASOSD.Web.Services.Interfaces;

/// <summary>
/// Service for managing navigation menus and items.
/// </summary>
public interface INavigationService
{
    #region Menus
    
    /// <summary>
    /// Gets all navigation menus for admin listing.
    /// </summary>
    Task<List<NavigationMenuListViewModel>> GetAllMenusAsync(CancellationToken ct = default);
    
    /// <summary>
    /// Gets a menu by ID with all items for editing.
    /// </summary>
    Task<NavigationMenuEditViewModel?> GetMenuForEditingAsync(string id, CancellationToken ct = default);
    
    /// <summary>
    /// Gets a menu by slug with all items for editing.
    /// </summary>
    Task<NavigationMenuEditViewModel?> GetMenuBySlugAsync(string slug, CancellationToken ct = default);
    
    /// <summary>
    /// Creates a new navigation menu.
    /// </summary>
    Task<Result<NavigationMenuEditViewModel>> CreateMenuAsync(NavigationMenuFormViewModel model, string userId, CancellationToken ct = default);
    
    /// <summary>
    /// Updates an existing navigation menu.
    /// </summary>
    Task<Result<NavigationMenuEditViewModel>> UpdateMenuAsync(NavigationMenuFormViewModel model, string userId, CancellationToken ct = default);
    
    /// <summary>
    /// Deletes a navigation menu and all its items.
    /// </summary>
    Task<r> DeleteMenuAsync(string id, CancellationToken ct = default);
    
    /// <summary>
    /// Gets menus for dropdown selection.
    /// </summary>
    Task<List<NavigationMenuSelectItem>> GetMenusForSelectAsync(CancellationToken ct = default);
    
    #endregion
    
    #region Items
    
    /// <summary>
    /// Gets a single item by ID.
    /// </summary>
    Task<NavigationItemViewModel?> GetItemByIdAsync(string id, CancellationToken ct = default);
    
    /// <summary>
    /// Adds a new item to a menu.
    /// </summary>
    Task<Result<NavigationItemViewModel>> AddItemAsync(NavigationItemFormViewModel model, CancellationToken ct = default);
    
    /// <summary>
    /// Updates an existing item.
    /// </summary>
    Task<Result<NavigationItemViewModel>> UpdateItemAsync(NavigationItemFormViewModel model, CancellationToken ct = default);
    
    /// <summary>
    /// Deletes an item and reorders siblings.
    /// </summary>
    Task<r> DeleteItemAsync(string id, CancellationToken ct = default);
    
    /// <summary>
    /// Moves an item up in display order.
    /// </summary>
    Task<r> MoveItemUpAsync(string id, CancellationToken ct = default);
    
    /// <summary>
    /// Moves an item down in display order.
    /// </summary>
    Task<r> MoveItemDownAsync(string id, CancellationToken ct = default);
    
    /// <summary>
    /// Indents an item (makes it a child of the previous sibling).
    /// </summary>
    Task<r> IndentItemAsync(string id, CancellationToken ct = default);
    
    /// <summary>
    /// Outdents an item (moves it up one level).
    /// </summary>
    Task<r> OutdentItemAsync(string id, CancellationToken ct = default);
    
    /// <summary>
    /// Bulk reorders items (for drag-and-drop).
    /// </summary>
    Task<r> BulkReorderItemsAsync(NavigationItemsBulkReorderViewModel model, CancellationToken ct = default);
    
    #endregion
    
    #region Rendering
    
    /// <summary>
    /// Gets a menu ready for rendering in a template.
    /// </summary>
    Task<NavigationRenderModel?> GetMenuForRenderingAsync(string menuId, string? currentPageSlug = null, CancellationToken ct = default);
    
    /// <summary>
    /// Gets a menu by slug ready for rendering.
    /// </summary>
    Task<NavigationRenderModel?> GetMenuBySlugForRenderingAsync(string slug, string? currentPageSlug = null, CancellationToken ct = default);
    
    #endregion
    
    #region Helpers
    
    /// <summary>
    /// Gets all published pages for dropdown selection in navigation editor.
    /// </summary>
    Task<List<PageSelectItem>> GetPagesForSelectAsync(CancellationToken ct = default);
    
    #endregion
}
