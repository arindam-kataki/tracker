namespace ASOSD.Web.Entities;

/// <summary>
/// Represents a single item within a navigation menu.
/// </summary>
public class NavigationItem
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    
    /// <summary>
    /// The menu this item belongs to.
    /// </summary>
    public string MenuId { get; set; } = string.Empty;
    
    /// <summary>
    /// Parent item ID for nested navigation (null = top level).
    /// </summary>
    public string? ParentId { get; set; }
    
    /// <summary>
    /// Display text for the navigation link.
    /// </summary>
    public string Label { get; set; } = string.Empty;
    
    /// <summary>
    /// Type of navigation item.
    /// </summary>
    public NavigationItemType Type { get; set; } = NavigationItemType.Page;
    
    /// <summary>
    /// Linked page ID (for Page type).
    /// </summary>
    public string? PageId { get; set; }
    
    /// <summary>
    /// External URL (for Link type).
    /// </summary>
    public string? Url { get; set; }
    
    /// <summary>
    /// Link target (_self or _blank).
    /// </summary>
    public string Target { get; set; } = "_self";
    
    /// <summary>
    /// Sort order within parent level.
    /// </summary>
    public int DisplayOrder { get; set; }
    
    /// <summary>
    /// Nesting depth (0 = top level, max 2 for 3 levels).
    /// </summary>
    public int Depth { get; set; } = 0;
    
    /// <summary>
    /// Whether this item is visible in navigation.
    /// </summary>
    public bool IsActive { get; set; } = true;
    
    /// <summary>
    /// Optional CSS class for custom styling.
    /// </summary>
    public string? CssClass { get; set; }
    
    // Navigation properties
    public NavigationMenu Menu { get; set; } = null!;
    public NavigationItem? Parent { get; set; }
    public ICollection<NavigationItem> Children { get; set; } = new List<NavigationItem>();
    public PageContent? Page { get; set; }
}

/// <summary>
/// Types of navigation items.
/// </summary>
public enum NavigationItemType
{
    /// <summary>
    /// Links to an internal page.
    /// </summary>
    Page = 0,
    
    /// <summary>
    /// Links to an external URL.
    /// </summary>
    Link = 1,
    
    /// <summary>
    /// Non-clickable header/group label.
    /// </summary>
    Header = 2
}
