using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ASOSD.Web.Services.Interfaces;
using ASOSD.Web.ViewModels;

namespace ASOSD.Web.Controllers;

/// <summary>
/// Handles navigation menu management.
/// </summary>
[Authorize(Policy = "ContentAdmin")]
[Route("admin/navigation")]
public class NavigationController : BaseAdminController
{
    private readonly INavigationService _navigation;

    public NavigationController(INavigationService navigation)
    {
        _navigation = navigation;
    }

    #region Menus

    [HttpGet("")]
    public async Task<IActionResult> Index(CancellationToken ct)
    {
        var menus = await _navigation.GetAllMenusAsync(ct);
        return View("Menus", menus);
    }

    [HttpGet("create")]
    public IActionResult Create()
    {
        return View("EditMenu", new NavigationMenuEditViewModel());
    }

    [HttpPost("create")]
    public async Task<IActionResult> Create([FromForm] NavigationMenuFormViewModel model, CancellationToken ct)
    {
        var result = await _navigation.CreateMenuAsync(model, CurrentUserId, ct);
        if (result.IsFailure)
        {
            ViewBag.Errors = result.Errors;
            return View("EditMenu", new NavigationMenuEditViewModel
            {
                Name = model.Name,
                Slug = model.Slug,
                Description = model.Description,
                IsActive = model.IsActive
            });
        }
        TempData["Success"] = "Menu created successfully.";
        return RedirectToAction("Edit", new { id = result.Value.Id });
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Edit(string id, CancellationToken ct)
    {
        var menu = await _navigation.GetMenuForEditingAsync(id, ct);
        if (menu == null)
        {
            TempData["Error"] = "Menu not found.";
            return RedirectToAction("Index");
        }

        menu.AvailablePages = await _navigation.GetPagesForSelectAsync(ct);
        return View("EditMenu", menu);
    }

    [HttpPost("{id}")]
    public async Task<IActionResult> Edit(string id, [FromForm] NavigationMenuFormViewModel model, CancellationToken ct)
    {
        model = model with { Id = id };
        var result = await _navigation.UpdateMenuAsync(model, CurrentUserId, ct);
        if (result.IsFailure)
        {
            ViewBag.Errors = result.Errors;
            var menu = await _navigation.GetMenuForEditingAsync(id, ct);
            if (menu != null)
                menu.AvailablePages = await _navigation.GetPagesForSelectAsync(ct);
            return View("EditMenu", menu);
        }
        TempData["Success"] = "Menu saved successfully.";
        return RedirectToAction("Edit", new { id });
    }

    [HttpPost("{id}/delete")]
    public async Task<IActionResult> Delete(string id, CancellationToken ct)
    {
        var result = await _navigation.DeleteMenuAsync(id, ct);
        TempData[result.IsFailure ? "Error" : "Success"] = result.IsFailure ? result.Error : "Menu deleted.";
        return RedirectToAction("Index");
    }

    #endregion

    #region Items

    [HttpPost("{menuId}/items")]
    public async Task<IActionResult> AddItem(string menuId, [FromForm] NavigationItemFormViewModel model, CancellationToken ct)
    {
        model = model with { MenuId = menuId };
        var result = await _navigation.AddItemAsync(model, ct);
        
        if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
        {
            if (result.IsFailure)
                return BadRequest(new { success = false, error = result.Error });
            return Ok(new { success = true, item = result.Value });
        }

        TempData[result.IsFailure ? "Error" : "Success"] = result.IsFailure ? result.Error : "Item added.";
        return RedirectToAction("Edit", new { id = menuId });
    }

    [HttpPost("{menuId}/items/{itemId}")]
    public async Task<IActionResult> UpdateItem(string menuId, string itemId, [FromForm] NavigationItemFormViewModel model, CancellationToken ct)
    {
        model = model with { Id = itemId, MenuId = menuId };
        var result = await _navigation.UpdateItemAsync(model, ct);

        if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
        {
            if (result.IsFailure)
                return BadRequest(new { success = false, error = result.Error });
            return Ok(new { success = true, item = result.Value });
        }

        TempData[result.IsFailure ? "Error" : "Success"] = result.IsFailure ? result.Error : "Item updated.";
        return RedirectToAction("Edit", new { id = menuId });
    }

    [HttpPost("{menuId}/items/{itemId}/delete")]
    public async Task<IActionResult> DeleteItem(string menuId, string itemId, CancellationToken ct)
    {
        var result = await _navigation.DeleteItemAsync(itemId, ct);

        if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
        {
            if (result.IsFailure)
                return BadRequest(new { success = false, error = result.Error });
            return Ok(new { success = true });
        }

        TempData[result.IsFailure ? "Error" : "Success"] = result.IsFailure ? result.Error : "Item deleted.";
        return RedirectToAction("Edit", new { id = menuId });
    }

    [HttpPost("{menuId}/items/{itemId}/move-up")]
    public async Task<IActionResult> MoveItemUp(string menuId, string itemId, CancellationToken ct)
    {
        var result = await _navigation.MoveItemUpAsync(itemId, ct);

        if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
        {
            if (result.IsFailure)
                return BadRequest(new { success = false, error = result.Error });
            return Ok(new { success = true });
        }

        TempData[result.IsFailure ? "Error" : "Success"] = result.IsFailure ? result.Error : "Item moved.";
        return RedirectToAction("Edit", new { id = menuId });
    }

    [HttpPost("{menuId}/items/{itemId}/move-down")]
    public async Task<IActionResult> MoveItemDown(string menuId, string itemId, CancellationToken ct)
    {
        var result = await _navigation.MoveItemDownAsync(itemId, ct);

        if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
        {
            if (result.IsFailure)
                return BadRequest(new { success = false, error = result.Error });
            return Ok(new { success = true });
        }

        TempData[result.IsFailure ? "Error" : "Success"] = result.IsFailure ? result.Error : "Item moved.";
        return RedirectToAction("Edit", new { id = menuId });
    }

    [HttpPost("{menuId}/items/{itemId}/indent")]
    public async Task<IActionResult> IndentItem(string menuId, string itemId, CancellationToken ct)
    {
        var result = await _navigation.IndentItemAsync(itemId, ct);

        if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
        {
            if (result.IsFailure)
                return BadRequest(new { success = false, error = result.Error });
            return Ok(new { success = true });
        }

        TempData[result.IsFailure ? "Error" : "Success"] = result.IsFailure ? result.Error : "Item indented.";
        return RedirectToAction("Edit", new { id = menuId });
    }

    [HttpPost("{menuId}/items/{itemId}/outdent")]
    public async Task<IActionResult> OutdentItem(string menuId, string itemId, CancellationToken ct)
    {
        var result = await _navigation.OutdentItemAsync(itemId, ct);

        if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
        {
            if (result.IsFailure)
                return BadRequest(new { success = false, error = result.Error });
            return Ok(new { success = true });
        }

        TempData[result.IsFailure ? "Error" : "Success"] = result.IsFailure ? result.Error : "Item outdented.";
        return RedirectToAction("Edit", new { id = menuId });
    }

    [HttpPost("{menuId}/reorder")]
    public async Task<IActionResult> BulkReorder(string menuId, [FromBody] NavigationItemsBulkReorderViewModel model, CancellationToken ct)
    {
        model.MenuId = menuId;
        var result = await _navigation.BulkReorderItemsAsync(model, ct);

        if (result.IsFailure)
            return BadRequest(new { success = false, error = result.Error });

        return Ok(new { success = true });
    }

    #endregion

    #region API Endpoints

    [HttpGet("api/pages")]
    public async Task<IActionResult> GetPagesForSelect(CancellationToken ct)
    {
        var pages = await _navigation.GetPagesForSelectAsync(ct);
        return Json(pages);
    }

    [HttpGet("api/menus")]
    public async Task<IActionResult> GetMenusForSelect(CancellationToken ct)
    {
        var menus = await _navigation.GetMenusForSelectAsync(ct);
        return Json(menus);
    }

    #endregion
}
