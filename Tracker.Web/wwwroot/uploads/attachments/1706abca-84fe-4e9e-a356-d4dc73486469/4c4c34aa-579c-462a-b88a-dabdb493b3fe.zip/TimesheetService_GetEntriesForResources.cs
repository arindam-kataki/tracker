// Add this method to TimesheetService.cs:

/// <summary>
/// Gets time entries for multiple resources within a date range.
/// Used for team/manager timesheet rollup views.
/// </summary>
public async Task<List<TimeEntry>> GetEntriesForResourcesAsync(
    List<string> resourceIds,
    List<string>? serviceAreaIds = null,
    DateOnly? startDate = null,
    DateOnly? endDate = null)
{
    if (resourceIds == null || !resourceIds.Any())
        return new List<TimeEntry>();

    var query = _db.TimeEntries
        .Include(te => te.Resource)
        .Include(te => te.Enhancement)
            .ThenInclude(e => e.ServiceArea)
        .Include(te => te.WorkPhase)
        .Include(te => te.ConsolidationSources)
        .Where(te => resourceIds.Contains(te.ResourceId));

    // Filter by service areas if specified
    if (serviceAreaIds != null && serviceAreaIds.Any())
    {
        query = query.Where(te => serviceAreaIds.Contains(te.Enhancement.ServiceAreaId));
    }

    // Filter by date range
    if (startDate.HasValue)
        query = query.Where(te => te.EndDate >= startDate.Value);

    if (endDate.HasValue)
        query = query.Where(te => te.StartDate <= endDate.Value);

    return await query
        .OrderBy(te => te.Enhancement.ServiceArea.Code)
        .ThenBy(te => te.Enhancement.WorkId)
        .ThenByDescending(te => te.StartDate)
        .ToListAsync();
}
