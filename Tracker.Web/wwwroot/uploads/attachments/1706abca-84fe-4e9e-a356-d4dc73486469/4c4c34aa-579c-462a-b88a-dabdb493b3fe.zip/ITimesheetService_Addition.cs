// Add this method to ITimesheetService.cs:

/// <summary>
/// Gets time entries for multiple resources within a date range.
/// Used for team/manager timesheet rollup views.
/// </summary>
/// <param name="resourceIds">List of resource IDs to include</param>
/// <param name="serviceAreaIds">Optional: limit to specific service areas</param>
/// <param name="startDate">Start of date range</param>
/// <param name="endDate">End of date range</param>
/// <returns>List of time entries for all specified resources</returns>
Task<List<TimeEntry>> GetEntriesForResourcesAsync(
    List<string> resourceIds,
    List<string>? serviceAreaIds = null,
    DateOnly? startDate = null,
    DateOnly? endDate = null);
