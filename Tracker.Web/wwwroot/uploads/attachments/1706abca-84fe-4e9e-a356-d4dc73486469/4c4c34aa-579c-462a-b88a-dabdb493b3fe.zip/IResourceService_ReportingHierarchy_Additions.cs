// Add these methods to IResourceService.cs in the #region Reporting Hierarchy section:

/// <summary>
/// Gets all direct reports for a resource across all service areas.
/// </summary>
/// <param name="resourceId">The manager's resource ID</param>
/// <returns>List of resources who report directly to this manager</returns>
Task<List<Resource>> GetAllDirectReportsAsync(string resourceId);

/// <summary>
/// Gets all resources in the reporting chain downwards (direct + indirect reports) recursively.
/// Includes the manager themselves.
/// </summary>
/// <param name="resourceId">The manager's resource ID</param>
/// <param name="serviceAreaIds">Optional: limit to specific service areas</param>
/// <returns>List of all resources in the reporting chain (including self)</returns>
Task<List<Resource>> GetReportingChainDownwardsAsync(string resourceId, List<string>? serviceAreaIds = null);

/// <summary>
/// Checks if a resource has any direct reports in any service area.
/// Used for access control to Team Timesheet view.
/// </summary>
/// <param name="resourceId">The resource ID to check</param>
/// <returns>True if the resource has at least one direct report</returns>
Task<bool> HasDirectReportsAsync(string resourceId);

/// <summary>
/// Checks if a resource has any direct reports in the specified service areas.
/// </summary>
/// <param name="resourceId">The resource ID to check</param>
/// <param name="serviceAreaIds">Service areas to check within</param>
/// <returns>True if the resource has at least one direct report in any of the specified service areas</returns>
Task<bool> HasDirectReportsInServiceAreasAsync(string resourceId, List<string> serviceAreaIds);
