# Tracker Enhancement Details Update

This update includes:
1. **More prominent section headings** in the Ticket Details tab
2. **Inline add/remove** for Sponsors, SPOCs, Resources, and Skills
3. **New Notifications tab** with persisted recipients per enhancement

## Files to Update/Add

### New Files
- `Entities/EnhancementNotificationRecipient.cs` - New entity for storing notification recipients

### Modified Files
- `ViewModels/EnhancementDetailsViewModel.cs` - Added `NotificationsViewModel` and related classes
- `Views/Enhancements/_TicketDetails.cshtml` - Updated with prominent headers and inline resource management
- `Views/Enhancements/_Notifications.cshtml` - New partial view for the Notifications tab
- `Views/Enhancements/Details.cshtml` - Added Notifications tab

### Additional Changes Needed

#### 1. Update Enhancement.cs Entity
Add this navigation property:
```csharp
public virtual ICollection<EnhancementNotificationRecipient> NotificationRecipients { get; set; } = new List<EnhancementNotificationRecipient>();
```

#### 2. Update TrackerDbContext.cs
Add DbSet:
```csharp
public DbSet<EnhancementNotificationRecipient> EnhancementNotificationRecipients => Set<EnhancementNotificationRecipient>();
```

Add to OnModelCreating:
```csharp
// EnhancementNotificationRecipient
modelBuilder.Entity<EnhancementNotificationRecipient>(entity =>
{
    entity.HasKey(e => e.Id);
    
    entity.HasIndex(e => e.EnhancementId);
    entity.HasIndex(e => new { e.EnhancementId, e.ResourceId }).IsUnique();

    entity.HasOne(e => e.Enhancement)
        .WithMany(e => e.NotificationRecipients)
        .HasForeignKey(e => e.EnhancementId)
        .OnDelete(DeleteBehavior.Cascade);

    entity.HasOne(e => e.Resource)
        .WithMany()
        .HasForeignKey(e => e.ResourceId)
        .OnDelete(DeleteBehavior.Cascade);
});
```

#### 3. Update EnhancementDetailsController.cs
Add the methods from `Controller_NotificationMethods.cs`:
- `AddNotificationRecipient` action
- `RemoveNotificationRecipient` action
- Update `BuildDetailsViewModelAsync` to populate Notifications

Add `using` for TrackerDbContext if not already present, and inject it:
```csharp
private readonly TrackerDbContext _context;

// Add to constructor
public EnhancementDetailsController(..., TrackerDbContext context, ...) : base(authService)
{
    _context = context;
    // ... other assignments
}
```

#### 4. Run Migration
```bash
cd Tracker.Web
dotnet ef migrations add AddEnhancementNotificationRecipients
dotnet ef database update
```

## UI Changes

### Ticket Details Tab
- Each section now has a prominent colored header with icon
- Sponsors, SPOCs, Resources, and Skills now have inline add/remove buttons
- Click "Add [Type]" to show available options
- Click the X button to remove an assignment
- Click the + button to add an assignment

### Notifications Tab
- Left panel shows current recipients with remove button
- Right panel shows available resources with search filter
- Quick action buttons to add all Sponsors/SPOCs/Resources at once
- Recipients are persisted to the database

## Quick Actions in Notifications Tab
- **Add All Sponsors**: Adds all resources of type "Client"
- **Add All SPOCs**: Adds all resources of type "SPOC"  
- **Add All Assigned**: Adds all resources of type "Internal"
