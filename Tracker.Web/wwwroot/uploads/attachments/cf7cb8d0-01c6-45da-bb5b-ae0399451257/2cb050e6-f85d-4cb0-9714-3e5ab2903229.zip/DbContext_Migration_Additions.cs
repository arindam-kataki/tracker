// ============================================================
// 1. Add to TrackerDbContext.cs - DbSet declaration
// ============================================================

public DbSet<EnhancementNotificationRecipient> EnhancementNotificationRecipients => Set<EnhancementNotificationRecipient>();


// ============================================================
// 2. Add to TrackerDbContext.cs - OnModelCreating method
// ============================================================

// EnhancementNotificationRecipient
modelBuilder.Entity<EnhancementNotificationRecipient>(entity =>
{
    entity.HasKey(e => e.Id);
    
    entity.HasIndex(e => e.EnhancementId);
    entity.HasIndex(e => new { e.EnhancementId, e.ResourceId }).IsUnique();

    entity.HasOne(e => e.Enhancement)
        .WithMany(e => e.NotificationRecipients)
        .HasForeignKey(e => e.EnhancementId)
        .OnDelete(DeleteBehavior.Cascade);

    entity.HasOne(e => e.Resource)
        .WithMany()
        .HasForeignKey(e => e.ResourceId)
        .OnDelete(DeleteBehavior.Cascade);
});


// ============================================================
// 3. Add to Enhancement.cs entity - Navigation property
// ============================================================

// Add this to the Enhancement entity class:
public virtual ICollection<EnhancementNotificationRecipient> NotificationRecipients { get; set; } = new List<EnhancementNotificationRecipient>();


// ============================================================
// 4. Migration commands to run
// ============================================================

// Run these commands in the Tracker.Web directory:
// dotnet ef migrations add AddEnhancementNotificationRecipients
// dotnet ef database update
