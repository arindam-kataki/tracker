// Add these methods to EnhancementDetailsController.cs

#region Notification Recipients

[HttpPost]
[ValidateAntiForgeryToken]
public async Task<IActionResult> AddNotificationRecipient([FromBody] AddNotificationRecipientRequest request)
{
    if (string.IsNullOrEmpty(request.EnhancementId) || string.IsNullOrEmpty(request.ResourceId))
        return Json(new { success = false, message = "Invalid request" });

    var enhancement = await _enhancementService.GetByIdAsync(request.EnhancementId);
    if (enhancement == null)
        return Json(new { success = false, message = "Enhancement not found" });

    // Check if already exists
    var existing = await _context.EnhancementNotificationRecipients
        .FirstOrDefaultAsync(r => r.EnhancementId == request.EnhancementId && r.ResourceId == request.ResourceId);
    
    if (existing != null)
        return Json(new { success = false, message = "Recipient already added" });

    var recipient = new EnhancementNotificationRecipient
    {
        EnhancementId = request.EnhancementId,
        ResourceId = request.ResourceId,
        CreatedBy = CurrentUserId
    };

    _context.EnhancementNotificationRecipients.Add(recipient);
    await _context.SaveChangesAsync();

    return Json(new { success = true, recipientId = recipient.Id });
}

[HttpPost]
[ValidateAntiForgeryToken]
public async Task<IActionResult> RemoveNotificationRecipient([FromBody] RemoveNotificationRecipientRequest request)
{
    if (string.IsNullOrEmpty(request.RecipientId))
        return Json(new { success = false, message = "Invalid request" });

    var recipient = await _context.EnhancementNotificationRecipients.FindAsync(request.RecipientId);
    if (recipient == null)
        return Json(new { success = false, message = "Recipient not found" });

    _context.EnhancementNotificationRecipients.Remove(recipient);
    await _context.SaveChangesAsync();

    return Json(new { success = true });
}

#endregion

// Request models - add to ViewModels folder or at the end of the controller file
public class AddNotificationRecipientRequest
{
    public string EnhancementId { get; set; } = string.Empty;
    public string ResourceId { get; set; } = string.Empty;
}

public class RemoveNotificationRecipientRequest
{
    public string RecipientId { get; set; } = string.Empty;
}

// ============================================================
// Update BuildDetailsViewModelAsync to include Notifications
// Add this code inside the method after the TimeRecording section
// ============================================================

// Notifications
var notificationRecipients = await _context.EnhancementNotificationRecipients
    .Include(r => r.Resource)
    .ThenInclude(r => r.ResourceType)
    .Where(r => r.EnhancementId == enhancementId)
    .ToListAsync();

// Get all active resources for the service area (all types)
var allServiceAreaResources = await _resourceService.GetActiveAsync();

model.Notifications = new NotificationsViewModel
{
    EnhancementId = enhancementId,
    SelectedRecipientIds = notificationRecipients.Select(r => r.ResourceId).ToList(),
    AvailableResources = allServiceAreaResources.Select(r => new NotificationRecipientOption
    {
        Id = r.Id,
        Name = r.Name,
        Email = r.Email,
        ResourceType = r.ResourceType?.Name
    }).ToList(),
    CurrentRecipients = notificationRecipients.Select(r => new NotificationRecipientViewModel
    {
        Id = r.Id,
        ResourceId = r.ResourceId,
        ResourceName = r.Resource?.Name ?? "Unknown",
        Email = r.Resource?.Email,
        ResourceType = r.Resource?.ResourceType?.Name,
        AddedAt = r.CreatedAt,
        AddedBy = r.CreatedBy
    }).ToList()
};
